1.All linked list based implementation is present in Linked_list.cpp file.

2.All array based implementation is present in arr.cpp file.

3.To use any implementation used must include the Linked_list.cpp or arr.cpp files and an object of class linkedlist 
	have to be created.The source files gives user ten basic function of the ADT.User can only use those functions.