#include <iostream>
#include <cstdlib>

#include "Linked_list_double.cpp"
// #include "arr.cpp"

using namespace std;

template<class T>
class newlist : public linkedlist <T>
{
public:
    int append(T data)
    {
        moveToEnd();
        next();
        insert(data);

        return -1;
    }
    int clear()
    {
        moveToEnd();
        while (length() != 0)
        {
            remove();
        }
        return -1;
    }
    int search(T val)
    {
        moveToStart();
        int position = -1;
        for (int i = 0; i < length(); i++)
        {
            if (val == getValue())
            {
                return currPos();
            }
            next();
        }
        return position;
    }
};

int main()
{

    int K, X, P, Q;

    newlist<int> list;

    int returnval;
    // Type of return val variable depends of the list datatype.

    scanf("%d %d", &K, &X);
    if (K > X)
    {
        cout << "Error input" << endl;
        return -1;
    }

    list.init(X);
    for (int i = 0; i < K; i++)
    {
        int temp;
        if (i == (K - 1))
        {
            scanf("%d", &temp);
        }
        else
        {
            scanf("%d ", &temp);
        }
        // list.moveToEnd();
        // list.next();
        // list.insert(temp);
        list.append(temp);
    }

    list.printlist();
    while (1)
    {
        cin >> Q;
        switch (Q)
        {
        case 0:
            exit(0);
            break;

        case 1:
            returnval = list.clear();
            list.printlist();
            cout << returnval << endl;
            break;

        case 2:
            cout << "Enter parameter:";
            cin >> P;
            returnval = list.append(P);
            list.printlist();
            cout << returnval << endl;
            break;
        case 3:
            cout << "Enter parameter:";
            cin >> P;
            returnval = list.search(P);
            list.printlist();
            cout << returnval << endl;
            break;
        default:
            break;
        }
    }
    return 0;
}