#include <iostream>
using namespace std;

template <class T>
class linkedlist
{
    struct _SingleLL
    {
        T item;
        struct _SingleLL *next;
    };
    struct _SingleLL *head;
    struct _SingleLL *tail;
    struct _SingleLL *currentnode;
    int currentposition;
    int length;

public:
    void init()
    {
        head = tail = currentnode = NULL;
        currentposition=-1;
        Length=0;
    }

    int insert(T data)
    {
        /*Add a case for enlongating the tail*/
        return -1;
    }
    T remove()
    {
        T temp;//store the value of removed node.
        /*
            code for removing.
        */

        return temp;
    }
    int moveToStart()
    {
        return -1;
    }
    int moveToEnd()
    {
        return -1;
    }
    int prev()
    {
        return -1;
    }
    int length()
    {
        return Length;
    }
    int currPos()
    {
        return currentposition;
    }
    int moveToPos(int pos)
    {

    }
    T getValue()
    {
        
    }

    void printlist()
    {
        
    }

};

int main()
{

    return 0;
}