#include <iostream>
#include "Headers\Array_list.cpp"

template <typename type>
class Queue
{
protected:
    linkedlist<type> q1;
    int Front, tail, Length, queuesize;

public:
    Queue()
    {
        Front = tail = -1;
        Length = 0;
        queuesize = 10;
        q1.setmaxlength(queuesize);
    }

    Queue(int x)
    {
        Front = tail = -1;
        Length = 0;
        queuesize = x;
        q1.setmaxlength(queuesize);
    }

    void enqueue(type data)
    {
        if (Length == queuesize)
        {
            queuesize =queuesize*2;
            q1.circulargrow(Front,tail);
        }
        if (Front == -1&&tail == -1)
        {
            Front = tail = 0;
            q1.moveToPos(Front);
            q1.changeval(data);
        }
        else
        {
            tail=(tail+1)%queuesize;
            q1.moveToPos(tail);
            q1.changeval(data);
        }

        Length++;
    }
    type dequeue()
    {
        if (Length != 0)
        {
            q1.moveToPos(Front);
            type temp = q1.getValue();
            Front = (Front + 1) % queuesize;
            Length--;
            if(Length==0)
                Front=tail=-1;
            return temp;
        }
        else 
            return (type)NULL;
    }

    int length()
    {
        return Length;
    }

    type front()
    {
        if (Length > 0)
        {
            q1.moveToPos(Front);
            return q1.getValue();
        }
        else
            return (type)NULL;
    }

    type back()
    {
        if (Length > 0)
        {
            q1.moveToPos(tail);
            return q1.getValue();
        }
        else
            return (type)NULL;
    }

    bool is_empty()
    {
        if(Length>0)
            return false;
        else
            return true;
    }

    void clear()
    {
        Front=tail=-1;
    }

    void printqueue()
    {
        std::cout<<"<";
        if(Front<=tail&&Length>0)
        {
            for(int i=Front;i<=tail;i++)
            {
                q1.moveToPos(i);
                std::cout<<q1.getValue();
                if(i!=tail)
                    std::cout<<",";
            }
        }
        if(Front>tail)
        {
            //while(1)
            {
                for(int i=Front;i<queuesize;i++)
                {
                    q1.moveToPos(i);
                    std::cout<<q1.getValue()<<",";
                }
                for(int i=Front;i<queuesize;i++)
                {
                    q1.moveToPos(i);
                    std::cout<<q1.getValue();
                    if(i!=tail)
                        std::cout<<",";
                }
            }
        }
        // int i=Front;
        // while(1)
        // {
        //     q1.moveToPos(i);
        //     std::cout<<q1.getValue();
        //     if(i!=tail)
        //     {
        //         std::cout<<",";
        //     }
        //     if(i==tail)
        //         break;
        //     i++;
        // }
        std::cout<<">"<<std::endl;
    }

    void print()
    {
        q1.printlist();
    }

    // void useless()
    // {
    //     q1.moveToPos(0);
    //     q1.changeval(1);
    //     q1.moveToPos(1);
    //     q1.changeval(1);
    //     q1.moveToPos(2);
    //     q1.changeval(1);
    //     tail=3;
    // }
};

// int main()
// {
//     Queue<int> q;
//     q.enqueue(5);
//     q.printqueue();
//     q.enqueue(5);
//     q.printqueue();
//     q.enqueue(5);
//     q.printqueue();
//     q.enqueue(5);
//     q.printqueue();
//     // q.useless();
//     // q.printqueue();

//     return 0;
// }
