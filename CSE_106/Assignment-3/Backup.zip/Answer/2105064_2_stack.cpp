#include <iostream>
#include <cstdlib>
#include <string>
#include <cstring>


#include "2105064_1_a_queue.cpp"
//#include "2105064_1_ll_queue.cpp"

template <typename type>
class Stack
{
private:
    Queue<type> q_main,q_temp;
    int size;

public:
    

    Stack()
    {
        size=0;
    }

    void clear()
    {
        q_main.clear();//Holds the stack
        q_temp.clear();//Temporary stores the items during push.
    }

    void push(type item)
    {
        q_temp.enqueue(item);

        while(!q_main.is_empty())
        {
            q_temp.enqueue(q_main.dequeue());
        }

        while(!q_temp.is_empty())
        {
            q_main.enqueue(q_temp.dequeue());
        }
    }

    type pop()
    {
        return q_main.dequeue();
    }

    int length()
    {
        return size;
    }

    type topValue()
    {
        return q_main.front();
    }

    bool isEmpty()
    {
        return q_main.is_empty();
    }

    void printstack()
    {
        //Needs some modification.
        int l=q_main.length();
        type *arr=new type[l];
        
        for(int i=0;i<l;i++)
        {
            arr[i]=q_main.front();
            q_temp.enqueue(q_main.dequeue());
        }

        std::cout<<"<";
        for(int i=l-1;i>=0;i--)
        {
            std::cout<<arr[i];
            if(i!=0)
                std::cout<<",";
        }
        std::cout<<">"<<std::endl;

        delete[] arr;

        while(!q_temp.is_empty())
        {
            q_main.enqueue(q_temp.dequeue());
        }
        
        
    }

    
};

