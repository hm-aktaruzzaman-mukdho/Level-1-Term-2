#include <iostream>
#include "Headers\Linked_list_double.cpp"

template <typename type>
class Queue
{
protected:
    linkedlist<type> queue;

public:
    void enqueue(type data)
    {
        queue.append(data);
        
    }
    type dequeue()
    {
        queue.moveToStart();
        return queue.remove();
    }
    int length()
    {
        return queue.length();
    }
    type front()
    {
        queue.moveToStart();
        return queue.getValue();
    }
    type back()
    {
        queue.moveToEnd();
        return queue.getValue();
    }
    bool is_empty()
    {
        if(queue.length()==0)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    void clear()
    {
        
        queue.moveToStart();
        int l=queue.length();
        for(int i=0;i<l;i++)
        {
            queue.remove();
        }
    }
    void printqueue()
    {
        queue.moveToStart();
        int l=queue.length();
        std::cout<<"<";
        for(int i=0;i<l;i++)
        {
            std::cout<<queue.getValue();
            if(i<(l-1))
                std::cout<<",";
            queue.next();
        }
        std::cout<<">"<<std::endl;
    }
};
