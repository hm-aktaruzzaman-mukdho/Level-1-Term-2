package controllers;

import javafx.application.HostServices;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import models.Movie;
import models.MovieList;
import models.ProductionCompany;
import client.Main;
import util.LogoutDTO;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

public class HomeController {

    private Main main;

    private ConcurrentHashMap<String,String> trailerList;

    @FXML
    private Label message;

    @FXML
    private ImageView image;

    @FXML
    private Button button;

    @FXML
    private ListView<Button> myList;
    @FXML
    private Label movieName;
    @FXML
    private Label listLabel;
    @FXML
    private Label profitLabel;
    @FXML
    private Label countLabel;

    @FXML
    private Button recentMoviesBtn;
    @FXML
    private Button homeBtn;

    @FXML
    private Button maxRevBtn;
    @FXML
    private Button addMovieBtn;
    @FXML
    private Label movieDuration;

    @FXML
    private Label movieGenre;
    @FXML
    private Label movieYear;

    @FXML
    private Label movieBudget;
    @FXML
    private Label movieRevenue;
    @FXML
    private Button transferMovieBtn;

    // v2

    @FXML
    private Button passChangeBtn;
    @FXML
    private ImageView moviePoster;
    @FXML
    private ImageView companyPoster;
    @FXML
    private Label notiLabel;

    @FXML
    private Hyperlink watchLink;

    @FXML
    private Button searchBtn;
    List<String> dummies = new ArrayList<>();






    public void init(ProductionCompany p, String listType, MovieList movieList, String noti) {
        main.setCompanyName(p.getName());
        message.setText(p.getName());
        //Image img = new Image(Main.class.getResourceAsStream("img/GoodWillHuntingposter.jpg"));

        listLabel.setText(listType);
        String profitText = "Total Profit: " + p.getTotalProfit();
        profitLabel.setText(profitText);
        String countText = "Total Movies: " + p.getMovieCount();
        countLabel.setText(countText);
        unsetMovieDetails();
        hightlight(homeBtn);

        //v2 start

        notiLabel.setText(noti);
        trailerList = p.getTrailerList();
        //System.out.println(trailerList.size());
        /*for(String s: trailerList.keySet()){
            System.out.println(s + " : " + trailerList.get(s));
        }*/

        passChangeBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                try {
                    main.showChangePassPage(p);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        //v2 end

        //v3

        for(String s: p.getTrailerList().keySet()){
            if(p.getTrailerList().get(s).equals("dummy")){
                dummies.add(s);
            }
        }

        //v3

        buildListView(p.getCompanyMovies());
        homeBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                unsetMovieDetails();
                unHighlightAllMenu();
                hightlight(homeBtn);
                listLabel.setText("All Movies");
                buildListView(movieList);
            }
        });
        recentMoviesBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                unsetMovieDetails();
                unHighlightAllMenu();
                hightlight(recentMoviesBtn);
                listLabel.setText("Most Recent Movies");
                MovieList mm;
                if(movieList==null || movieList.getMovieCount()==0){
                    mm = null;
                }
                else{
                    mm = movieList.searchByCompanyLatest(p.getName());
                }
                buildListView(mm);
            }
        });
        maxRevBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                unsetMovieDetails();
                unHighlightAllMenu();
                hightlight(maxRevBtn);
                listLabel.setText("Maximum Revenue Movies");
                MovieList mm;
                if(movieList==null || movieList.getMovieCount()==0){
                    mm = null;
                }
                else{
                    mm = movieList.searchByCompanyMaxRevenue(p.getName());
                }
                buildListView(mm);}
        });
        transferMovieBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                try {
                    main.showTransferPage(p);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        addMovieBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                try {
                    main.showAddMoviePage(p);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        searchBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                try {
                    main.showSearchMoviePage(p);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });



        if(listType.equals("Recent")){
            unsetMovieDetails();
            unHighlightAllMenu();
            hightlight(recentMoviesBtn);
            listLabel.setText("Most Recent Movies");
            buildListView(movieList.searchByCompanyLatest(p.getName()));
        }
        else if(listType.equals("Max")){
            unsetMovieDetails();
            unHighlightAllMenu();
            hightlight(maxRevBtn);
            listLabel.setText("Maximum Revenue Movies");
            buildListView(movieList.searchByCompanyMaxRevenue(p.getName()));
        }

    }

    public void unsetMovieDetails(){
        moviePoster.setImage(null);
        movieName.setText("");
        movieGenre.setText("");
        movieDuration.setText("");
        movieYear.setText("");
        movieBudget.setText("");
        movieRevenue.setText("");
    }

    public void setMovieDetails(Movie m){

        //v2

        watchLink.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                HostServices hostServices = main.getHostServices();
                String link = trailerList.get(m.getTitle());
                String demoLink = "https://www.google.com";
                hostServices.showDocument(link);
                watchLink.setVisited(false);
            }
        });

        String name = m.getTitle();
        String path = "";
        for(int i=0;i<name.length();i++){
            char ch = name.charAt(i);
            if((ch>=48 && ch<=57) || (ch>=64 && ch<=122)){
                path = path + name.charAt(i);
            }
        }

        path = "src/main/resources/images/" + path + "poster.jpg";
        if(dummies.contains(m.getTitle())){
            path = "src/main/resources/images/dummy.jpg";
        }



        File file = new File(path);
        Image img = new Image(file.toURI().toString());
        moviePoster.setImage(img);



        moviePoster.setStyle("-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.8), 10, 0, 0, 10);");

        //v2

        String genreText = "";
        int n = m.getGenres().size();
        System.out.println(m.getTitle() + " has " + n + " genres.");
        for (int i=0;i<n-1;i++) {
            genreText = genreText + m.getGenres().get(i) + " | ";
        }
        genreText = genreText + m.getGenres().get(n-1);
        System.out.println(genreText);
        movieName.setText(m.getTitle());
        movieGenre.setText(genreText);
        movieDuration.setText("Duration: " + m.getRunningTime()+" minutes ");
        movieYear.setText("Released in "+m.getReleaseYear());
        movieBudget.setText("Budget: "+ m.getBudget());
        movieRevenue.setText("Revenue: "+m.getRevenue());
    }

    public void unHighlightAllMenu(){
        unHightlight(homeBtn);
        unHightlight(recentMoviesBtn);
        unHightlight(maxRevBtn);
        unHightlight(addMovieBtn);
    }
    public void hightlight(Button btn){
        btn.setStyle("-fx-background-color: #90ee90 ; -fx-background-radius: 20;");
    }

    public void unHightlight(Button btn){
        btn.setStyle("-fx-background-color: white ; -fx-background-radius: 20;");
    }
    public void buildListView(MovieList movieList){
        myList.getItems().clear();
        unsetMovieDetails();
        if(movieList==null || movieList.getMovieCount()==0)
            return;
        setMovieDetails(movieList.getMovieList().get(0));
        List<Button> movieButtons = new ArrayList<>();
        for(Movie m: movieList.getMovieList()){
            Button button = new Button();
            button.setText(m.getTitle());
            button.setStyle(" -fx-background-color: #353535; -fx-text-fill: white; -fx-background-radius: 40;");
            Font font = Font.font("Franklin Gothic Demi", FontWeight.BOLD,25);
            button.setFont(font);
            //button.setMinWidth(30);
            button.setPrefWidth(280);
            button.setPrefHeight(70);
            button.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    unHighlightAllMovieButtons(movieButtons);
                    Button b = (Button)e.getSource();
                    b.setStyle(" -fx-background-color: #353535; -fx-text-fill: #00ffff; -fx-background-radius: 40;");
                    String name = b.getText();
                    movieName.setText(name);
                    MovieList mm = movieList.searchByTitle(name);
                    Movie m = mm.getMovieList().get(0);
                    setMovieDetails(m);
                }
            });
            movieButtons.add(button);
        }
        myList.getItems().addAll(movieButtons);
        movieButtons.get(0).setStyle(" -fx-background-color: #353535; -fx-text-fill: #00ffff; -fx-background-radius: 40;");  // default highlight first one
    }

    public void unHighlightAllMovieButtons(List<Button>movieButtons){
        for(Button btn: movieButtons){
            btn.setStyle(" -fx-background-color: #353535; -fx-text-fill: white; -fx-background-radius: 40;");
        }
    }

    @FXML
    public void logoutAction(ActionEvent event) {
        var lDTO = new LogoutDTO(main.getCompanyName());
        lDTO.setStatus(true);
        try {
            main.getNetworkUtil().write(lDTO);
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            main.showLoginPage();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void setMain(Main main) {
        this.main = main;
    }

}
