package util;

public class MovieListDTO {

}
