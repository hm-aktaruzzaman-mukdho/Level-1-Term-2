package s2105064.client.controller;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import s2105064.CommonClass.Food;
import s2105064.CommonClass.SocketWrapper;
import s2105064.client.MainClientApp;
import s2105064.client.RestaurantClient;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

public class FoodCartRestaurantController {
    public TableView<Map.Entry<Food, Integer>> datatableshow;
    public TableColumn<Map.Entry<Food, Integer>,String> foodname;
    public TableColumn<Map.Entry<Food, Integer>,String> category;
    public TableColumn<Map.Entry<Food, Integer>,Double> price;
    public TableColumn<Map.Entry<Food,Integer>,String> quantity;


    private HashMap<Food,Integer> orderpoolrestaurant;

    public void setOrderpoolrestaurant(HashMap<Food, Integer> orderpoolrestaurant) {
        this.orderpoolrestaurant = orderpoolrestaurant;
    }

    RestaurantClient restaurantclient;

    public void setRestaurantclient(RestaurantClient restaurantclient) {
        this.restaurantclient=restaurantclient;
    }

    MainClientApp main;

    public void setMain(MainClientApp main) {
        this.main = main;
    }

    public void goBack(ActionEvent actionEvent) throws Exception {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirmation Dialog");
        alert.setHeaderText("YOU ARE ABOUT TO GO BACK");
        //alert.setContentText("Are you sure you want to continue?");
        ButtonType okButton = new ButtonType("OK");
        ButtonType cancelButton = new ButtonType("Cancel", ButtonType.CANCEL.getButtonData());
        alert.getButtonTypes().setAll(okButton, cancelButton);
        Optional<ButtonType> result = alert.showAndWait();
        // Check which button was pressed
        if (result.isPresent() && result.get() == okButton) {
            main.startUpdate=true;
            restaurantclient.getServerSocket().write("killupdate");
            main.showRestaurantHomeScrene();
        } else {
        }
    }

    public void showDataonTable() throws Exception {
        //ObservableList<Map.Entry<Food,Integer>> entrylist = FXCollections.observableArrayList(orderpoolrestaurant.entrySet());
        if(main.startUpdate)
        {
            CartUpdateThread crt = new CartUpdateThread(restaurantclient, orderpoolrestaurant, datatableshow);
            Thread newThread = new Thread(crt);
            newThread.start();
            main.startUpdate=false;
            //This Thread is created only once.
        }
        foodname.setCellValueFactory(Data -> new SimpleStringProperty(Data.getValue().getKey().getName()));
        category.setCellValueFactory(Data -> new SimpleStringProperty(Data.getValue().getKey().getCatagory()));
        price.setCellValueFactory(Data -> new SimpleObjectProperty<>(Data.getValue().getKey().getPrice()));
        quantity.setCellValueFactory(Data -> {
            Object o= Data.getValue().getValue();
            String x=String.valueOf(o);
            return new SimpleStringProperty(x);
        });

        //datatableshow.setItems(entrylist);
    }
}
