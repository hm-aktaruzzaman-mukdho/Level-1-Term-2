package s2105064.client;

import s2105064.CommonClass.SocketWrapper;

public class CustomerClient {
    private SocketWrapper serversocket;
    private String hostname;
    private int port;
    private String username,password;
    private boolean isaccepted;

    public boolean isAccepted() {
        return isaccepted;
    }
    public CustomerClient(String hostname, int port) throws Exception {
        this.hostname = hostname;
        this.port = port;
        serversocket = new SocketWrapper(hostname, port);
        System.out.println("server connected");

        //connectAndCommunicate();
    }

    public void setCredentials(String username,String password) {
        this.username = username;
        this.password = password;
        this.isaccepted=true;
    }


    public void connectAndCommunicate()
    {
        try {
            serversocket.write("customer");
            String status= (String) serversocket.read();
            isaccepted=status.equalsIgnoreCase("accepted");
            if(status.equalsIgnoreCase("accepted"))
            {
                System.out.println("You are accepted");
            }
            else{
                System.out.println("You are not accepted");
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public SocketWrapper getServersocket()
    {
        return serversocket;
    }

    public void terminateconnection() throws Exception
    {
        serversocket.write("terminate");
        serversocket.closeConnection();
    }
}
