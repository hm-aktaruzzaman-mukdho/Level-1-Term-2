package s2105064.client.controller;

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.TableView;
import s2105064.CommonClass.Food;
import s2105064.CommonClass.SocketWrapper;
import s2105064.client.RestaurantClient;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class CartUpdateThread implements Runnable {
    private final TableView<Map.Entry<Food, Integer>> datatableshow;
    //public Thread thread;
    RestaurantClient restaurantclient;
    HashMap<Food, Integer> orderpoolrestaurant;


    CartUpdateThread(RestaurantClient restaurantclient, HashMap<Food, Integer> orderpoolrestaurant, TableView<Map.Entry<Food, Integer>> datatableshow) {
        this.restaurantclient = restaurantclient;
        this.orderpoolrestaurant = orderpoolrestaurant;

        this.datatableshow = datatableshow;
    }

    @Override
    public void run() {
        SocketWrapper socket = restaurantclient.getServerSocket();
        boolean keepAlive = true;
        try {
            while (keepAlive) {
                String command = (String) socket.read();
                if (command.equalsIgnoreCase("orders")) {
                    HashMap<Food, Integer> gottendata = (HashMap<Food, Integer>) socket.read();
                    for (Food f : gottendata.keySet()) {
                        //System.out.println(f.Foodcontentforfile());
                        if (orderpoolrestaurant.get(f) != null) {
                            int x = orderpoolrestaurant.get(f);
                            orderpoolrestaurant.put(f, x + gottendata.get(f));
                        } else {
                            orderpoolrestaurant.put(f, gottendata.get(f));
                        }
                    }
                } else if (command.equalsIgnoreCase("kill")) {
                    keepAlive = false;
                    break;
                }
//                for (Food f : orderpoolrestaurant.keySet()) {
//                    System.out.println(f.Foodcontentforfile() + "   " + orderpoolrestaurant.get(f));
//                }

                ObservableList<Map.Entry<Food,Integer>> entrylist = FXCollections.observableArrayList(orderpoolrestaurant.entrySet());
                datatableshow.setItems(entrylist);

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
