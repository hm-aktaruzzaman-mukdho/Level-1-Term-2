package s2105064.server.controller;

public class HomeScreneServer {
}
